// 0/1 Knapsack Algorithm using Dynamic Programming (with DP Table generation)
function knapsack(values, weights, W) {
  let n = values.length;
  let dp = Array(n + 1)
    .fill()
    .map(() => Array(W + 1).fill(0));

  for (let i = 1; i <= n; i++) {
    for (let w = 1; w <= W; w++) {
      if (weights[i - 1] <= w) {
        dp[i][w] = Math.max(
          dp[i - 1][w],
          dp[i - 1][w - weights[i - 1]] + values[i - 1]
        );
      } else {
        dp[i][w] = dp[i - 1][w];
      }
    }
  }

  // Display the DP table
  generateDPTable(dp);

  return dp[n][W]; // Return the maximum value in the knapsack
}

// Function to handle user input and call the knapsack function
function solveKnapsack() {
  // Get the input values
  const weightsInput = document.getElementById("weights").value;
  const valuesInput = document.getElementById("values").value;
  const capacityInput = document.getElementById("capacity").value;

  // Convert the inputs into arrays and integer
  const weights = weightsInput.split(",").map(Number);
  const values = valuesInput.split(",").map(Number);
  const capacity = parseInt(capacityInput);

  // Validate the input
  if (weights.length !== values.length || isNaN(capacity)) {
    document.getElementById("result").innerText = "Please enter valid input!";
    return;
  }

  // Call the knapsack function
  const maxValue = knapsack(values, weights, capacity);

  // Display the result
  document.getElementById("result").innerText =
    "Maximum value the thief can carry: " + maxValue;

  // Call function to generate the item table
  generateItemTable(values, weights);
}

// Function to generate the table for items, weights, and values
function generateItemTable(values, weights) {
  let tableContainer = document.getElementById("table-container");
  tableContainer.innerHTML = ""; // Clear previous table content

  let table = document.createElement("table");

  // Create table header
  let headerRow = document.createElement("tr");
  let headers = ["Item", "Weight", "Value"];
  headers.forEach((headerText) => {
    let th = document.createElement("th");
    th.innerText = headerText;
    headerRow.appendChild(th);
  });
  table.appendChild(headerRow);

  // Populate table with item, weight, and value data
  for (let i = 0; i < values.length; i++) {
    let row = document.createElement("tr");

    // Item number (index + 1)
    let itemCell = document.createElement("td");
    itemCell.innerText = i + 1;
    row.appendChild(itemCell);

    // Weight
    let weightCell = document.createElement("td");
    weightCell.innerText = weights[i];
    row.appendChild(weightCell);

    // Value
    let valueCell = document.createElement("td");
    valueCell.innerText = values[i];
    row.appendChild(valueCell);

    table.appendChild(row);
  }

  tableContainer.appendChild(table);
}

// Function to generate the DP table
function generateDPTable(dp) {
  let dpTableContainer = document.getElementById("dp-table-container");
  dpTableContainer.innerHTML = ""; // Clear previous DP table content

  let table = document.createElement("table");

  // Create table header row for weights (columns)
  let headerRow = document.createElement("tr");
  let th = document.createElement("th");
  th.innerText = "Item\\Weight";
  headerRow.appendChild(th);

  // Add column headers for weight capacity
  for (let i = 0; i < dp[0].length; i++) {
    let th = document.createElement("th");
    th.innerText = i;
    headerRow.appendChild(th);
  }
  table.appendChild(headerRow);

  // Populate table rows with DP values
  for (let i = 0; i < dp.length; i++) {
    let row = document.createElement("tr");

    // Row header (item number)
    let itemCell = document.createElement("td");
    itemCell.innerText = i === 0 ? 0 : i; // First row is for 0 items
    row.appendChild(itemCell);

    // DP values
    for (let w = 0; w < dp[i].length; w++) {
      let valueCell = document.createElement("td");
      valueCell.innerText = dp[i][w];
      row.appendChild(valueCell);
    }

    table.appendChild(row);
  }

  dpTableContainer.appendChild(table);
}
