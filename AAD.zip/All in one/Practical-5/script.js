function minCoins(coins, N) {
  // Initialize dp array with Infinity (large value)
  let dp = new Array(N + 1).fill(Infinity);
  dp[0] = 0; // Base case: No coins needed to make 0

  // Create an array to track coins used
  let coinsUsed = new Array(N + 1).fill(null).map(() => []);

  // Create table dynamically
  let tableHtml = `<table><tr><th>Amount (i)</th><th>Minimum Coins (dp[i])</th><th>Coins Used</th></tr>`;

  // Fill dp array and generate table rows
  for (let i = 1; i <= N; i++) {
    for (let coin of coins) {
      if (i - coin >= 0 && dp[i - coin] + 1 < dp[i]) {
        dp[i] = dp[i - coin] + 1;
        // Update the coins used for the current amount
        coinsUsed[i] = [...coinsUsed[i - coin], coin];
      }
    }
    // Add row for current `i`
    tableHtml += `<tr><td>${i}</td><td>${
      dp[i] === Infinity ? "-" : dp[i]
    }</td><td>${coinsUsed[i].length ? coinsUsed[i].join(", ") : "-"}</td></tr>`;
  }

  // Close the table
  tableHtml += "</table>";
  
  let clutter = ``;
  coinsUsed[N].forEach((e) => {
    clutter += `<h1>${e}</h1>`; // Appending each coin to the clutter string
  });
  
  let ansDiv = document.createElement('div');
  ansDiv.classList.add('ansDiv');

  let ansText= document.createElement('h1');
  ansText.textContent="Coins Required are: ";
  ansDiv.appendChild(ansText);

  let finalAns = document.createElement("div");
  finalAns.classList.add('finalAns');
  finalAns.innerHTML = clutter; // Setting the innerHTML of the paragraph
  ansDiv.appendChild(finalAns); // Add the paragraph to the body (or any other container)
  
  document.body.appendChild(ansDiv)
  // Display the table in the HTML container
  document.getElementById("table-container").innerHTML = tableHtml;

  return dp[N] === Infinity ? -1 : dp[N]; // If dp[N] is still Infinity, return -1 (no solution)
}

// Function to generate the table based on user input
function generateTable() {
  const coinsInput = document.getElementById("coins").value;
  const coins = coinsInput.split(",").map(Number);
  const targetAmount = parseInt(document.getElementById("target").value);

  const minCoinsResult = minCoins(coins, targetAmount);
  console.log("Minimum number of coins required:", minCoinsResult);
}
